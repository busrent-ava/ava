const { useState, useEffect, useRef, useCallback, useMemo } = React;

// ─────────────────────────────────────────────
// Constants & Seed Data
// ─────────────────────────────────────────────
const ADMIN_PASS = 'admin123';
const STORAGE_KEY = 'fleetshift_v1';
const QUEUE_KEY = 'fleetshift_queue_v1';

const SEED_DRIVERS = [
  { id: 'DRV-1001', name: 'Ahmed Al-Mansoori', bus: 'DXB-4821', phone: '+971501234001', pin: '1001', status: 'active' },
  { id: 'DRV-1002', name: 'Mohammed Hassan', bus: 'SHJ-3190', phone: '+971501234002', pin: '1002', status: 'active' },
  { id: 'DRV-1003', name: 'Fatima Al-Kaabi', bus: 'AUH-7742', phone: '+971501234003', pin: '1003', status: 'active' },
  { id: 'DRV-1004', name: 'Rajesh Kumar', bus: 'DXB-5518', phone: '+971501234004', pin: '1004', status: 'locked' },
];

const STAGES = [
  { id: 1, key: 'start', title: 'Before Trip Start', subtitle: 'Record starting odometer & photo', icon: 'Play' },
  { id: 2, key: 'dest', title: 'Reached Destination', subtitle: 'Arrival / parking odometer', icon: 'MapPin' },
  { id: 3, key: 'returnStart', title: 'Before Return Start', subtitle: 'Odometer before return leg', icon: 'RotateCcw' },
  { id: 4, key: 'final', title: 'Final Return Parking', subtitle: 'Complete shift & sync', icon: 'Flag' },
];

// ─────────────────────────────────────────────
// Storage helpers
// ─────────────────────────────────────────────
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Migrate: ensure every driver has a pin
      if (parsed.drivers) {
        parsed.drivers = parsed.drivers.map(d => ({
          ...d,
          pin: d.pin || (d.id && d.id.replace(/\D/g, '').slice(-4)) || '0000',
        }));
      }
      return parsed;
    }
  } catch (e) {}
  return {
    drivers: SEED_DRIVERS,
    trips: [],
    extras: [],
    expenses: [],
    buses: ['DXB-4821', 'SHJ-3190', 'AUH-7742', 'DXB-5518', 'DXB-2201', 'AUH-8800'],
  };
}

function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function loadQueue() {
  try {
    return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveQueue(q) {
  localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
}

// ─────────────────────────────────────────────
// Utils
// ─────────────────────────────────────────────
function uid(prefix = 'ID') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function formatDate(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleString('en-AE', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false,
  });
}

function formatKm(n) {
  if (n == null || n === '') return '—';
  return Number(n).toLocaleString('en') + ' km';
}

function daysAgo(ts) {
  return (Date.now() - ts) / (1000 * 60 * 60 * 24);
}

function Icon({ name, size = 20, className = '' }) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const icon = lucide.createElement(lucide.icons[name] || lucide.icons.Circle);
      icon.setAttribute('width', size);
      icon.setAttribute('height', size);
      icon.setAttribute('stroke-width', '2');
      ref.current.appendChild(icon);
    }
  }, [name, size]);
  return <span ref={ref} className={`inline-flex items-center justify-center ${className}`} />;
}

// ─────────────────────────────────────────────
// Watermarked Camera Component
// ─────────────────────────────────────────────
function WatermarkCamera({ driver, bus, onCapture, onCancel }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const [gps, setGps] = useState(null);
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function start() {
      try {
        // GPS
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (pos) => {
              if (mounted) setGps({
                lat: pos.coords.latitude.toFixed(5),
                lng: pos.coords.longitude.toFixed(5),
              });
            },
            () => { if (mounted) setGps({ lat: 'N/A', lng: 'N/A' }); },
            { enableHighAccuracy: true, timeout: 8000 }
          );
        } else {
          setGps({ lat: 'N/A', lng: 'N/A' });
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (!mounted) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setReady(true);
        }
      } catch (err) {
        setError(err.message || 'Camera access denied');
      }
    }
    start();
    return () => {
      mounted = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  const capture = async () => {
    if (!videoRef.current || !canvasRef.current || !ready) return;
    setCapturing(true);
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);

    // Watermark badge
    const pad = 12;
    const lineH = 16;
    const lines = [
      `⏱ ${new Date().toLocaleString('en-AE', { hour12: false })}`,
      `👤 ${driver.name} (${driver.id})`,
      `🚌 ${bus}`,
      `📍 ${gps ? `${gps.lat}, ${gps.lng}` : 'GPS…'}`,
    ];
    const boxH = lines.length * lineH + pad * 2;
    const boxW = Math.min(canvas.width - 16, 340);
    const x = 8;
    const y = canvas.height - boxH - 8;

    ctx.fillStyle = 'rgba(0,0,0,0.78)';
    ctx.beginPath();
    ctx.roundRect(x, y, boxW, boxH, 8);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px ui-monospace, monospace';
    lines.forEach((line, i) => {
      ctx.fillText(line, x + pad, y + pad + (i + 0.8) * lineH);
    });

    // Accent stripe
    ctx.fillStyle = '#0ea5e9';
    ctx.fillRect(x, y, 4, boxH);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
    setCapturing(false);
    onCapture({ dataUrl, gps, timestamp: Date.now() });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      <div className="flex items-center justify-between p-3 bg-slate-900/90">
        <button onClick={onCancel} className="text-slate-300 text-sm flex items-center gap-1">
          <Icon name="X" size={18} /> Cancel
        </button>
        <span className="text-xs text-slate-400 font-medium">Watermarked Proof</span>
        <div className="w-16" />
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {error ? (
          <div className="text-center p-6">
            <Icon name="CameraOff" size={48} className="text-red-400 mb-3" />
            <p className="text-red-300 text-sm mb-4">{error}</p>
            <p className="text-slate-500 text-xs">Allow camera permission and try again.</p>
            <button onClick={onCancel} className="mt-4 px-4 py-2 bg-slate-800 rounded-lg text-sm">Close</button>
          </div>
        ) : (
          <>
            <video ref={videoRef} playsInline muted className="max-w-full max-h-full object-contain" />
            <canvas ref={canvasRef} className="hidden" />
            {ready && (
              <div className="absolute bottom-4 left-3 right-3 pointer-events-none">
                <div className="bg-black/70 text-white text-[10px] font-mono p-2 rounded-lg leading-relaxed border-l-4 border-sky-500">
                  <div>⏱ {new Date().toLocaleString('en-AE', { hour12: false })}</div>
                  <div>👤 {driver.name} ({driver.id})</div>
                  <div>🚌 {bus}</div>
                  <div>📍 {gps ? `${gps.lat}, ${gps.lng}` : 'Acquiring GPS…'}</div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {!error && (
        <div className="p-4 bg-slate-900/95 safe-bottom">
          <button
            onClick={capture}
            disabled={!ready || capturing}
            className="w-full py-4 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white font-semibold text-lg flex items-center justify-center gap-2"
          >
            <Icon name="Camera" size={22} />
            {capturing ? 'Processing…' : 'Capture Proof'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Network Simulator Badge
// ─────────────────────────────────────────────
function NetworkBadge({ online, syncing, queueLen, onToggle }) {
  let cls = online ? 'status-online' : 'status-offline';
  let label = online ? 'Online Sync' : 'Offline Mode';
  let icon = online ? 'Wifi' : 'WifiOff';
  if (syncing) {
    cls = 'status-syncing';
    label = 'Syncing…';
    icon = 'RefreshCw';
  }
  return (
    <button onClick={onToggle} className={`status-badge ${cls}`} title="Click to toggle network simulation">
      <Icon name={icon} size={12} />
      {label}
      {queueLen > 0 && (
        <span className="ml-1 bg-black/30 px-1.5 rounded-full text-[10px]">{queueLen}</span>
      )}
    </button>
  );
}

// ─────────────────────────────────────────────
// Driver Portal
// ─────────────────────────────────────────────
function DriverPortal({ state, setState, driver, online, setOnline, queue, setQueue, onLogout }) {
  const [tab, setTab] = useState('shift'); // shift | extras | expenses | history
  const [activeTrip, setActiveTrip] = useState(null);
  const [cameraOpen, setCameraOpen] = useState(null); // stage key or null
  const [odometerInput, setOdometerInput] = useState('');
  const [syncing, setSyncing] = useState(false);
  const [toast, setToast] = useState(null);

  // Extra trip form
  const [extraForm, setExtraForm] = useState({ startKm: '', endKm: '', note: '', time: '' });
  // Expense form
  const [expMode, setExpMode] = useState('calc'); // calc | direct
  const [expForm, setExpForm] = useState({ liters: '', price: '2.85', total: '', note: '', type: 'fuel' });

  const myTrips = useMemo(() => {
    return (state.trips || [])
      .filter(t => t.driverId === driver.id && daysAgo(t.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.trips, driver.id]);

  const myExtras = useMemo(() => {
    return (state.extras || [])
      .filter(e => e.driverId === driver.id && daysAgo(e.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.extras, driver.id]);

  const myExpenses = useMemo(() => {
    return (state.expenses || [])
      .filter(e => e.driverId === driver.id && daysAgo(e.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.expenses, driver.id]);

  const showToast = (msg, type = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  };

  // Find incomplete trip for today or create new
  useEffect(() => {
    const open = myTrips.find(t => t.status === 'in_progress');
    if (open) setActiveTrip(open);
  }, [myTrips]);

  const startNewShift = () => {
    const trip = {
      id: uid('TRIP'),
      driverId: driver.id,
      driverName: driver.name,
      bus: driver.bus,
      status: 'in_progress',
      stages: {},
      createdAt: Date.now(),
      completedAt: null,
    };
    setState(s => {
      const next = { ...s, trips: [trip, ...s.trips] };
      saveState(next);
      return next;
    });
    setActiveTrip(trip);
    setOdometerInput('');
    showToast('New shift started');
  };

  const openCameraForStage = (stageKey) => {
    if (!odometerInput || isNaN(Number(odometerInput))) {
      showToast('Enter a valid odometer reading first', 'err');
      return;
    }
    setCameraOpen(stageKey);
  };

  const handleCapture = (stageKey, photoData) => {
    const km = Number(odometerInput);
    const stageData = {
      odometer: km,
      photo: photoData.dataUrl,
      gps: photoData.gps,
      timestamp: photoData.timestamp,
    };

    setState(s => {
      const trips = s.trips.map(t => {
        if (t.id !== activeTrip.id) return t;
        const stages = { ...t.stages, [stageKey]: stageData };
        const done = STAGES.every(st => stages[st.key]);
        return {
          ...t,
          stages,
          status: done ? 'completed' : 'in_progress',
          completedAt: done ? Date.now() : null,
        };
      });
      const next = { ...s, trips };
      saveState(next);
      return next;
    });

    // Update local activeTrip
    setActiveTrip(prev => {
      if (!prev) return prev;
      const stages = { ...prev.stages, [stageKey]: stageData };
      const done = STAGES.every(st => stages[st.key]);
      return { ...prev, stages, status: done ? 'completed' : 'in_progress', completedAt: done ? Date.now() : null };
    });

    setCameraOpen(null);
    setOdometerInput('');
    showToast(`Stage "${STAGES.find(s => s.key === stageKey)?.title}" recorded`);

    // Enqueue for sync
    enqueue({ type: 'trip_stage', tripId: activeTrip.id, stageKey, data: stageData, driverId: driver.id });
  };

  const enqueue = (item) => {
    const entry = { ...item, id: uid('Q'), queuedAt: Date.now() };
    setQueue(q => {
      const next = [...q, entry];
      saveQueue(next);
      return next;
    });
    if (online) flushQueue();
  };

  const flushQueue = useCallback(async () => {
    if (!online || queue.length === 0) return;
    setSyncing(true);
    // Simulate network delay
    await new Promise(r => setTimeout(r, 900 + Math.random() * 600));
    console.log('[FleetShift] Syncing queue to cloud (simulated):', queue);
    setQueue([]);
    saveQueue([]);
    setSyncing(false);
    showToast(`Synced ${queue.length} item(s)`);
  }, [online, queue]);

  useEffect(() => {
    if (online && queue.length > 0) flushQueue();
  }, [online]);

  // Extra trip submit
  const submitExtra = () => {
    const start = Number(extraForm.startKm);
    const end = Number(extraForm.endKm);
    if (!start || !end || end < start) {
      showToast('Invalid odometer values', 'err');
      return;
    }
    const extra = {
      id: uid('EXT'),
      driverId: driver.id,
      driverName: driver.name,
      bus: driver.bus,
      startKm: start,
      endKm: end,
      distance: end - start,
      note: extraForm.note || '',
      time: extraForm.time || new Date().toISOString().slice(0, 16),
      createdAt: Date.now(),
    };
    setState(s => {
      const next = { ...s, extras: [extra, ...s.extras] };
      saveState(next);
      return next;
    });
    enqueue({ type: 'extra', data: extra });
    setExtraForm({ startKm: '', endKm: '', note: '', time: '' });
    showToast('Extra trip logged');
  };

  // Expense submit
  const submitExpense = () => {
    let amount = 0;
    if (expMode === 'calc') {
      const liters = Number(expForm.liters);
      const price = Number(expForm.price);
      if (!liters || !price) {
        showToast('Enter liters and price', 'err');
        return;
      }
      amount = +(liters * price).toFixed(2);
    } else {
      amount = Number(expForm.total);
      if (!amount) {
        showToast('Enter total amount', 'err');
        return;
      }
    }
    const exp = {
      id: uid('EXP'),
      driverId: driver.id,
      driverName: driver.name,
      bus: driver.bus,
      type: expForm.type,
      mode: expMode,
      liters: expMode === 'calc' ? Number(expForm.liters) : null,
      unitPrice: expMode === 'calc' ? Number(expForm.price) : null,
      amount,
      note: expForm.note || '',
      createdAt: Date.now(),
    };
    setState(s => {
      const next = { ...s, expenses: [exp, ...s.expenses] };
      saveState(next);
      return next;
    });
    enqueue({ type: 'expense', data: exp });
    setExpForm({ liters: '', price: '2.85', total: '', note: '', type: 'fuel' });
    showToast('Expense recorded');
  };

  const currentStageIndex = activeTrip
    ? STAGES.findIndex(s => !activeTrip.stages[s.key])
    : -1;

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800 backdrop-blur px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs text-slate-400">Driver Portal</div>
            <div className="font-semibold text-sm truncate">{driver.name}</div>
            <div className="text-[11px] text-sky-400 font-mono">{driver.bus} · {driver.id}</div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <NetworkBadge
              online={online}
              syncing={syncing}
              queueLen={queue.length}
              onToggle={() => setOnline(o => !o)}
            />
            <button onClick={onLogout} className="p-2 rounded-lg bg-slate-800 text-slate-300">
              <Icon name="LogOut" size={16} />
            </button>
          </div>
        </div>
      </header>

      {/* Toast */}
      {toast && (
        <div className={`fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-sm font-medium shadow-lg fade-in ${
          toast.type === 'err' ? 'bg-red-600 text-white' : 'bg-emerald-600 text-white'
        }`}>
          {toast.msg}
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
        {tab === 'shift' && (
          <div className="space-y-4 fade-in">
            {!activeTrip || activeTrip.status === 'completed' ? (
              <div className="card p-6 text-center">
                <div className="text-4xl mb-3">🚌</div>
                <h2 className="text-lg font-semibold mb-1">Ready for shift?</h2>
                <p className="text-slate-400 text-sm mb-5">Start the 4-stage progressive log for today.</p>
                <button
                  onClick={startNewShift}
                  className="w-full py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
                >
                  Start New Shift
                </button>
              </div>
            ) : (
              <>
                {/* Progress */}
                <div className="card p-4">
                  <div className="flex justify-between text-xs text-slate-400 mb-2">
                    <span>Shift Progress</span>
                    <span>{Object.keys(activeTrip.stages).length} / 4</span>
                  </div>
                  <div className="stage-bar">
                    <div
                      className="stage-bar-fill"
                      style={{ width: `${(Object.keys(activeTrip.stages).length / 4) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Stages */}
                {STAGES.map((stage, idx) => {
                  const done = !!activeTrip.stages[stage.key];
                  const isCurrent = idx === currentStageIndex;
                  const locked = idx > currentStageIndex;
                  const data = activeTrip.stages[stage.key];

                  return (
                    <div
                      key={stage.key}
                      className={`card p-4 transition-all ${
                        done ? 'stage-done' : isCurrent ? 'stage-active' : 'stage-locked'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          done ? 'bg-emerald-500/20 text-emerald-400' :
                          isCurrent ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-800 text-slate-500'
                        }`}>
                          <Icon name={done ? 'Check' : stage.icon} size={20} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm">{stage.title}</div>
                          <div className="text-xs text-slate-400 mb-2">{stage.subtitle}</div>

                          {done && data && (
                            <div className="mt-2 space-y-2">
                              <div className="text-xs font-mono text-emerald-300">
                                {formatKm(data.odometer)} · {formatDate(data.timestamp)}
                              </div>
                              {data.photo && (
                                <img
                                  src={data.photo}
                                  alt="proof"
                                  className="rounded-lg max-h-32 object-cover border border-slate-700"
                                />
                              )}
                            </div>
                          )}

                          {isCurrent && (
                            <div className="mt-3 space-y-3">
                              <div>
                                <label className="text-xs text-slate-400 block mb-1">Odometer (km)</label>
                                <input
                                  type="number"
                                  inputMode="decimal"
                                  value={odometerInput}
                                  onChange={e => setOdometerInput(e.target.value)}
                                  placeholder="e.g. 124580"
                                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-base"
                                />
                              </div>
                              <button
                                onClick={() => openCameraForStage(stage.key)}
                                className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold flex items-center justify-center gap-2"
                              >
                                <Icon name="Camera" size={18} />
                                Capture Photo & Save Stage
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {activeTrip.status === 'completed' && (
                  <div className="card p-4 border-emerald-500/40 bg-emerald-500/5 text-center">
                    <Icon name="CheckCircle" size={32} className="text-emerald-400 mb-2" />
                    <div className="font-semibold text-emerald-300">Shift Complete</div>
                    <div className="text-xs text-slate-400 mt-1">All 4 stages recorded · queued for sync</div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {tab === 'extras' && (
          <div className="space-y-4 fade-in">
            <div className="card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Icon name="Route" size={18} className="text-sky-400" /> Extra / Inter-City Trip
              </h3>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-slate-400">Start km</label>
                  <input
                    type="number"
                    value={extraForm.startKm}
                    onChange={e => setExtraForm(f => ({ ...f, startKm: e.target.value }))}
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400">End km</label>
                  <input
                    type="number"
                    value={extraForm.endKm}
                    onChange={e => setExtraForm(f => ({ ...f, endKm: e.target.value }))}
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                  />
                </div>
              </div>
              <div className="mb-3">
                <label className="text-xs text-slate-400">Departure time</label>
                <input
                  type="datetime-local"
                  value={extraForm.time}
                  onChange={e => setExtraForm(f => ({ ...f, time: e.target.value }))}
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>
              <div className="mb-4">
                <label className="text-xs text-slate-400">Note (optional)</label>
                <input
                  type="text"
                  value={extraForm.note}
                  onChange={e => setExtraForm(f => ({ ...f, note: e.target.value }))}
                  placeholder="e.g. Airport shuttle"
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>
              <button
                onClick={submitExtra}
                className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
              >
                Log Extra Trip
              </button>
            </div>

            {myExtras.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-slate-500 uppercase tracking-wide">Recent (30 days)</div>
                {myExtras.map(ex => (
                  <div key={ex.id} className="card p-3 text-sm">
                    <div className="flex justify-between">
                      <span className="font-medium">{formatKm(ex.startKm)} → {formatKm(ex.endKm)}</span>
                      <span className="text-sky-400 font-mono text-xs">{ex.distance} km</span>
                    </div>
                    {ex.note && <div className="text-slate-400 text-xs mt-1">{ex.note}</div>}
                    <div className="text-[11px] text-slate-500 mt-1">{formatDate(ex.createdAt)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'expenses' && (
          <div className="space-y-4 fade-in">
            <div className="card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Icon name="Fuel" size={18} className="text-amber-400" /> Fuel & Expenses
              </h3>

              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setExpMode('calc')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${
                    expMode === 'calc' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Calculation
                </button>
                <button
                  onClick={() => setExpMode('direct')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${
                    expMode === 'direct' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Direct Entry
                </button>
              </div>

              <div className="mb-3">
                <label className="text-xs text-slate-400">Type</label>
                <select
                  value={expForm.type}
                  onChange={e => setExpForm(f => ({ ...f, type: e.target.value }))}
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                >
                  <option value="fuel">Fuel</option>
                  <option value="wash">Vehicle Wash</option>
                  <option value="parking">Parking</option>
                  <option value="maintenance">Minor Maintenance</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {expMode === 'calc' ? (
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="text-xs text-slate-400">Liters</label>
                    <input
                      type="number"
                      step="0.01"
                      value={expForm.liters}
                      onChange={e => setExpForm(f => ({ ...f, liters: e.target.value }))}
                      className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">Price / L (AED)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={expForm.price}
                      onChange={e => setExpForm(f => ({ ...f, price: e.target.value }))}
                      className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  {expForm.liters && expForm.price && (
                    <div className="col-span-2 text-center text-sm text-emerald-400 font-mono">
                      = {(Number(expForm.liters) * Number(expForm.price)).toFixed(2)} AED
                    </div>
                  )}
                </div>
              ) : (
                <div className="mb-3">
                  <label className="text-xs text-slate-400">Total Amount (AED)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={expForm.total}
                    onChange={e => setExpForm(f => ({ ...f, total: e.target.value }))}
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                  />
                </div>
              )}

              <div className="mb-4">
                <label className="text-xs text-slate-400">Note</label>
                <input
                  type="text"
                  value={expForm.note}
                  onChange={e => setExpForm(f => ({ ...f, note: e.target.value }))}
                  placeholder="Station / description"
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>

              <button
                onClick={submitExpense}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold"
              >
                Save Expense
              </button>
            </div>

            {myExpenses.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-slate-500 uppercase tracking-wide">Recent (30 days)</div>
                {myExpenses.map(ex => (
                  <div key={ex.id} className="card p-3 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="capitalize font-medium">{ex.type}</span>
                      <span className="text-amber-400 font-mono font-semibold">{ex.amount.toFixed(2)} AED</span>
                    </div>
                    {ex.liters && (
                      <div className="text-xs text-slate-400 mt-0.5">{ex.liters} L × {ex.unitPrice} AED</div>
                    )}
                    {ex.note && <div className="text-slate-400 text-xs mt-1">{ex.note}</div>}
                    <div className="text-[11px] text-slate-500 mt-1">{formatDate(ex.createdAt)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'history' && (
          <div className="space-y-3 fade-in">
            <div className="text-xs text-slate-500 uppercase tracking-wide">Your logs (last 30 days)</div>
            {myTrips.length === 0 && (
              <div className="card p-6 text-center text-slate-500 text-sm">No trips yet</div>
            )}
            {myTrips.map(t => (
              <div key={t.id} className="card p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-sm">{formatDate(t.createdAt)}</div>
                    <div className="text-xs text-slate-400 font-mono">{t.bus}</div>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    t.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {t.status === 'completed' ? 'Completed' : 'In Progress'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {STAGES.map(s => {
                    const d = t.stages[s.key];
                    return (
                      <div key={s.key} className="bg-slate-800/60 rounded-lg p-2">
                        <div className="text-slate-500 truncate">{s.title}</div>
                        <div className="font-mono text-sky-300">{d ? formatKm(d.odometer) : '—'}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 border-t border-slate-800 backdrop-blur safe-bottom z-30">
        <div className="flex justify-around py-2">
          {[
            { id: 'shift', icon: 'ClipboardList', label: 'Shift' },
            { id: 'extras', icon: 'Route', label: 'Extras' },
            { id: 'expenses', icon: 'Wallet', label: 'Expenses' },
            { id: 'history', icon: 'History', label: 'History' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-[10px] font-medium ${
                tab === item.id ? 'text-sky-400' : 'text-slate-500'
              }`}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Camera modal */}
      {cameraOpen && (
        <WatermarkCamera
          driver={driver}
          bus={driver.bus}
          onCapture={(data) => handleCapture(cameraOpen, data)}
          onCancel={() => setCameraOpen(null)}
        />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Admin Portal
// ─────────────────────────────────────────────
function AdminPortal({ state, setState, online, setOnline, queue, setQueue, onLogout }) {
  const [tab, setTab] = useState('overview'); // overview | drivers | audit | buses
  const [showAddDriver, setShowAddDriver] = useState(false);
  const [newDriver, setNewDriver] = useState({ name: '', id: '', bus: '', phone: '', pin: '' });
  const [toast, setToast] = useState(null);
  const [pinResetNotice, setPinResetNotice] = useState(null); // { driverId, pin }

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const stats = useMemo(() => {
    const trips = state.trips || [];
    const expenses = state.expenses || [];
    const extras = state.extras || [];
    const completed = trips.filter(t => t.status === 'completed').length;
    const inProg = trips.filter(t => t.status === 'in_progress').length;
    const totalExp = expenses.reduce((s, e) => s + (e.amount || 0), 0);
    const activeDrivers = (state.drivers || []).filter(d => d.status === 'active').length;
    return { completed, inProg, totalExp, activeDrivers, extras: extras.length, trips: trips.length };
  }, [state]);

  const allSubmissions = useMemo(() => {
    const items = [];
    (state.trips || []).forEach(t => {
      items.push({
        id: t.id,
        type: 'trip',
        driverName: t.driverName,
        bus: t.bus,
        status: t.status,
        createdAt: t.createdAt,
        detail: `${Object.keys(t.stages || {}).length}/4 stages`,
      });
    });
    (state.extras || []).forEach(e => {
      items.push({
        id: e.id,
        type: 'extra',
        driverName: e.driverName,
        bus: e.bus,
        status: 'logged',
        createdAt: e.createdAt,
        detail: `${e.distance} km`,
      });
    });
    (state.expenses || []).forEach(e => {
      items.push({
        id: e.id,
        type: 'expense',
        driverName: e.driverName,
        bus: e.bus,
        status: e.type,
        createdAt: e.createdAt,
        detail: `${e.amount.toFixed(2)} AED`,
      });
    });
    return items.sort((a, b) => b.createdAt - a.createdAt);
  }, [state]);

  const toggleDriver = (id) => {
    setState(s => {
      const drivers = s.drivers.map(d =>
        d.id === id ? { ...d, status: d.status === 'active' ? 'locked' : 'active' } : d
      );
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('Driver status updated');
  };

  const reassignBus = (driverId, bus) => {
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, bus } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('Bus reassigned');
  };

  const addDriver = () => {
    if (!newDriver.name || !newDriver.id || !newDriver.bus) {
      showToast('Name, ID and Bus are required');
      return;
    }
    if (state.drivers.some(d => d.id === newDriver.id)) {
      showToast('Driver ID already exists');
      return;
    }
    const pin = (newDriver.pin || '').trim() || newDriver.id.replace(/\D/g, '').slice(-4) || '0000';
    if (pin.length < 4) {
      showToast('PIN must be at least 4 digits');
      return;
    }
    const d = {
      id: newDriver.id,
      name: newDriver.name,
      bus: newDriver.bus,
      phone: newDriver.phone || '',
      pin,
      status: 'active',
    };
    setState(s => {
      const buses = s.buses.includes(d.bus) ? s.buses : [...s.buses, d.bus];
      const next = { ...s, drivers: [...s.drivers, d], buses };
      saveState(next);
      return next;
    });
    setNewDriver({ name: '', id: '', bus: '', phone: '', pin: '' });
    setShowAddDriver(false);
    showToast('Driver added');
  };

  const updateDriverPin = (driverId, pin) => {
    const cleaned = String(pin || '').replace(/\D/g, '').slice(0, 6);
    if (cleaned.length < 4) {
      showToast('PIN must be at least 4 digits');
      return;
    }
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, pin: cleaned } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('PIN updated');
  };

  const resetDriverPin = (driverId) => {
    // Generate a memorable 4-digit temp PIN (avoid leading zeros for clarity)
    const newPin = String(1000 + Math.floor(Math.random() * 9000));
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, pin: newPin } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    setPinResetNotice({ driverId, pin: newPin });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800 backdrop-blur px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Admin Control Center</div>
            <div className="font-semibold">FleetShift</div>
          </div>
          <div className="flex items-center gap-2">
            <NetworkBadge online={online} syncing={false} queueLen={queue.length} onToggle={() => setOnline(o => !o)} />
            <button onClick={onLogout} className="p-2 rounded-lg bg-slate-800 text-slate-300">
              <Icon name="LogOut" size={16} />
            </button>
          </div>
        </div>
      </header>

      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-sm font-medium bg-sky-600 text-white shadow-lg fade-in">
          {toast}
        </div>
      )}

      <main className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
        {tab === 'overview' && (
          <div className="space-y-4 fade-in">
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Completed Shifts', value: stats.completed, icon: 'CheckCircle', color: 'text-emerald-400' },
                { label: 'In Progress', value: stats.inProg, icon: 'Loader', color: 'text-amber-400' },
                { label: 'Active Drivers', value: stats.activeDrivers, icon: 'Users', color: 'text-sky-400' },
                { label: 'Total Expenses', value: `${stats.totalExp.toFixed(0)} AED`, icon: 'Wallet', color: 'text-amber-400' },
              ].map(s => (
                <div key={s.label} className="card p-4">
                  <div className={`${s.color} mb-1`}><Icon name={s.icon} size={18} /></div>
                  <div className="text-xl font-bold">{s.value}</div>
                  <div className="text-[11px] text-slate-500">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="card p-4">
              <h3 className="font-semibold text-sm mb-3">Live Upload Feed</h3>
              {allSubmissions.slice(0, 8).length === 0 ? (
                <div className="text-slate-500 text-sm text-center py-6">No submissions yet</div>
              ) : (
                <div className="space-y-2">
                  {allSubmissions.slice(0, 8).map(item => (
                    <div key={item.id} className="flex items-center gap-3 text-sm py-2 border-b border-slate-800 last:border-0">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        item.type === 'trip' ? 'bg-sky-500/15 text-sky-400' :
                        item.type === 'extra' ? 'bg-violet-500/15 text-violet-400' :
                        'bg-amber-500/15 text-amber-400'
                      }`}>
                        <Icon name={item.type === 'trip' ? 'Bus' : item.type === 'extra' ? 'Route' : 'Fuel'} size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{item.driverName}</div>
                        <div className="text-[11px] text-slate-500">{item.bus} · {item.detail}</div>
                      </div>
                      <div className="text-[10px] text-slate-500 shrink-0">{formatDate(item.createdAt)}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'drivers' && (
          <div className="space-y-3 fade-in">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Driver Roster</h3>
              <button
                onClick={() => setShowAddDriver(true)}
                className="px-3 py-1.5 rounded-lg bg-sky-500 text-white text-sm font-medium flex items-center gap-1"
              >
                <Icon name="Plus" size={14} /> Add
              </button>
            </div>

            {state.drivers.map(d => (
              <div key={d.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold">{d.name}</div>
                    <div className="text-xs font-mono text-slate-400">{d.id}</div>
                    {d.phone && <div className="text-xs text-slate-500 mt-0.5">{d.phone}</div>}
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    d.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {d.status === 'active' ? 'Active' : 'Locked'}
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <label className="text-xs text-slate-500">Bus:</label>
                  <select
                    value={d.bus}
                    onChange={e => reassignBus(d.id, e.target.value)}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-sm"
                  >
                    {state.buses.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => toggleDriver(d.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                      d.status === 'active' ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {d.status === 'active' ? 'Deactivate' : 'Activate'}
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <label className="text-xs text-slate-500 shrink-0">PIN:</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    defaultValue={d.pin || ''}
                    key={`${d.id}-pin-${d.pin}`}
                    onBlur={e => {
                      const v = e.target.value.replace(/\D/g, '');
                      if (v && v !== d.pin) updateDriverPin(d.id, v);
                    }}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.target.blur();
                      }
                    }}
                    className="w-24 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-sm font-mono tracking-widest text-center"
                    maxLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`Reset PIN for ${d.name}? A new temporary PIN will be generated.`)) {
                        resetDriverPin(d.id);
                      }
                    }}
                    className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-amber-500/15 text-amber-400 border border-amber-500/30 hover:bg-amber-500/25 flex items-center gap-1"
                  >
                    <Icon name="KeyRound" size={12} /> Reset PIN
                  </button>
                </div>
              </div>
            ))}

            {showAddDriver && (
              <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
                <div className="card w-full max-w-md p-5 fade-in">
                  <h3 className="font-semibold mb-4">Onboard New Driver</h3>
                  <div className="space-y-3">
                    <input
                      placeholder="Full name"
                      value={newDriver.name}
                      onChange={e => setNewDriver(f => ({ ...f, name: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="Driver ID (e.g. DRV-1005)"
                      value={newDriver.id}
                      onChange={e => setNewDriver(f => ({ ...f, id: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="Bus number"
                      value={newDriver.bus}
                      onChange={e => setNewDriver(f => ({ ...f, bus: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="PIN (4–6 digits)"
                      value={newDriver.pin}
                      onChange={e => setNewDriver(f => ({ ...f, pin: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
                      inputMode="numeric"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 tracking-widest"
                    />
                    <input
                      placeholder="Phone (optional)"
                      value={newDriver.phone}
                      onChange={e => setNewDriver(f => ({ ...f, phone: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  <div className="flex gap-2 mt-5">
                    <button onClick={() => { setShowAddDriver(false); setNewDriver({ name: '', id: '', bus: '', phone: '', pin: '' }); }} className="flex-1 py-2.5 rounded-xl bg-slate-800 text-sm">Cancel</button>
                    <button onClick={addDriver} className="flex-1 py-2.5 rounded-xl bg-sky-500 text-white text-sm font-semibold">Add Driver</button>
                  </div>
                </div>
              </div>
            )}

            {pinResetNotice && (
              <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
                <div className="card w-full max-w-sm p-6 fade-in text-center">
                  <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
                    <Icon name="KeyRound" size={24} />
                  </div>
                  <h3 className="font-semibold text-lg mb-1">PIN Reset</h3>
                  <p className="text-sm text-slate-400 mb-4">
                    New temporary PIN for{' '}
                    <span className="text-slate-200 font-medium">
                      {state.drivers.find(x => x.id === pinResetNotice.driverId)?.name || pinResetNotice.driverId}
                    </span>
                  </p>
                  <div className="bg-slate-800 border border-slate-700 rounded-xl py-4 mb-4">
                    <div className="text-[11px] text-slate-500 uppercase tracking-wide mb-1">Share this PIN with the driver</div>
                    <div className="text-3xl font-mono font-bold tracking-[0.3em] text-amber-400">{pinResetNotice.pin}</div>
                  </div>
                  <p className="text-[11px] text-slate-500 mb-4">Driver should change it after login if needed (admin can edit anytime).</p>
                  <button
                    onClick={() => setPinResetNotice(null)}
                    className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'audit' && (
          <div className="space-y-3 fade-in">
            <h3 className="font-semibold">Master Audit Trail</h3>
            <div className="card overflow-hidden">
              <div className="table-wrap">
                <table className="text-sm">
                  <thead>
                    <tr className="bg-slate-900">
                      <th>Time</th>
                      <th>Type</th>
                      <th>Driver</th>
                      <th>Bus</th>
                      <th>Detail</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allSubmissions.length === 0 && (
                      <tr><td colSpan={6} className="text-center text-slate-500 py-8">No records</td></tr>
                    )}
                    {allSubmissions.map(item => (
                      <tr key={item.id}>
                        <td className="text-xs text-slate-400">{formatDate(item.createdAt)}</td>
                        <td className="capitalize">{item.type}</td>
                        <td>{item.driverName}</td>
                        <td className="font-mono text-xs">{item.bus}</td>
                        <td>{item.detail}</td>
                        <td>
                          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                            item.status === 'completed' || item.status === 'logged' ? 'bg-emerald-500/15 text-emerald-400' :
                            item.status === 'in_progress' ? 'bg-amber-500/15 text-amber-400' :
                            'bg-slate-700 text-slate-300'
                          }`}>{item.status}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'buses' && (
          <div className="space-y-3 fade-in">
            <h3 className="font-semibold">Fleet Buses</h3>
            <div className="grid gap-2">
              {state.buses.map(b => {
                const assigned = state.drivers.filter(d => d.bus === b);
                return (
                  <div key={b} className="card p-4 flex items-center justify-between">
                    <div>
                      <div className="font-mono font-semibold">{b}</div>
                      <div className="text-xs text-slate-500">
                        {assigned.length ? assigned.map(d => d.name).join(', ') : 'Unassigned'}
                      </div>
                    </div>
                    <Icon name="Bus" size={20} className="text-sky-400" />
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 border-t border-slate-800 backdrop-blur safe-bottom z-30">
        <div className="flex justify-around py-2">
          {[
            { id: 'overview', icon: 'LayoutDashboard', label: 'Overview' },
            { id: 'drivers', icon: 'Users', label: 'Drivers' },
            { id: 'audit', icon: 'ScrollText', label: 'Audit' },
            { id: 'buses', icon: 'Bus', label: 'Buses' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-[10px] font-medium ${
                tab === item.id ? 'text-sky-400' : 'text-slate-500'
              }`}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

// ─────────────────────────────────────────────
// Login / Role Select
// ─────────────────────────────────────────────
function LoginScreen({ state, onDriverLogin, onAdminLogin, forceDriver = false, forceAdmin = false }) {
  const initialMode = forceDriver ? 'driver' : forceAdmin ? 'admin' : null;
  const [mode, setMode] = useState(initialMode); // null | driver | admin
  const [selectedDriver, setSelectedDriver] = useState('');
  const [driverPin, setDriverPin] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');
  const [showForgotPin, setShowForgotPin] = useState(false);
  const pinRef = useRef(null);

  const activeDrivers = state.drivers.filter(d => d.status === 'active');

  const tryAdmin = () => {
    if (adminPass === ADMIN_PASS) {
      onAdminLogin();
    } else {
      setError('Incorrect passcode');
    }
  };

  const tryDriver = () => {
    const d = state.drivers.find(x => x.id === selectedDriver);
    if (!d || d.status !== 'active') {
      setError('Select an active driver');
      return;
    }
    const expected = String(d.pin || '').trim();
    const entered = String(driverPin || '').trim();
    if (!entered) {
      setError('Enter your PIN');
      return;
    }
    if (entered !== expected) {
      setError('Incorrect PIN');
      setDriverPin('');
      if (pinRef.current) pinRef.current.focus();
      return;
    }
    setError('');
    onDriverLogin(d);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="text-center mb-8">
        <div className="text-5xl mb-3">🚌</div>
        <h1 className="text-2xl font-bold tracking-tight">FleetShift</h1>
        <p className="text-slate-400 text-sm mt-1">
          {forceDriver ? 'Driver Portal · AVA Transport' :
           forceAdmin ? 'Admin Control Center · AVA Transport' :
           'AVA Transport · Trip & Expense System'}
        </p>
      </div>

      {!mode && (
        <div className="w-full max-w-sm space-y-3 fade-in">
          <button
            onClick={() => setMode('driver')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-400">
              <Icon name="User" size={24} />
            </div>
            <div>
              <div className="font-semibold">Driver Portal</div>
              <div className="text-xs text-slate-400">Log shifts, extras & expenses</div>
            </div>
          </button>
          <button
            onClick={() => setMode('admin')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center text-violet-400">
              <Icon name="Shield" size={24} />
            </div>
            <div>
              <div className="font-semibold">Admin Control Center</div>
              <div className="text-xs text-slate-400">Roster, audit & fleet overview</div>
            </div>
          </button>
        </div>
      )}

      {mode === 'driver' && (
        <div className="w-full max-w-sm card p-6 fade-in">
          {!forceDriver && (
            <button onClick={() => { setMode(null); setError(''); setDriverPin(''); }} className="text-xs text-slate-400 mb-4 flex items-center gap-1">
              <Icon name="ArrowLeft" size={14} /> Back
            </button>
          )}
          <h2 className="font-semibold mb-1">Driver Login</h2>
          <p className="text-xs text-slate-500 mb-4">Select your profile and enter your PIN</p>
          <label className="text-xs text-slate-400 block mb-1">Driver</label>
          <select
            value={selectedDriver}
            onChange={e => { setSelectedDriver(e.target.value); setError(''); setDriverPin(''); }}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4"
          >
            <option value="">— Choose driver —</option>
            {activeDrivers.map(d => (
              <option key={d.id} value={d.id}>{d.name} · {d.bus}</option>
            ))}
          </select>
          <label className="text-xs text-slate-400 block mb-1">PIN</label>
          <input
            ref={pinRef}
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            value={driverPin}
            onChange={e => { setDriverPin(e.target.value.replace(/\D/g, '')); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && tryDriver()}
            placeholder="••••"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4 text-center text-xl tracking-[0.4em] font-semibold"
            autoComplete="off"
          />
          {error && <div className="text-red-400 text-xs mb-3 flex items-center gap-1"><Icon name="AlertCircle" size={12} /> {error}</div>}
          <button
            onClick={tryDriver}
            disabled={!selectedDriver}
            className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
          >
            Unlock Portal
          </button>
          <button
            type="button"
            onClick={() => setShowForgotPin(true)}
            className="w-full mt-3 text-xs text-slate-400 hover:text-sky-400 py-1"
          >
            Forgot PIN?
          </button>
          <p className="text-[10px] text-slate-600 text-center mt-1">Demo PINs match last 4 of ID (e.g. 1001)</p>
        </div>
      )}

      {showForgotPin && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
          <div className="card w-full max-w-sm p-6 fade-in">
            <div className="w-12 h-12 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center mx-auto mb-3">
              <Icon name="KeyRound" size={22} />
            </div>
            <h3 className="font-semibold text-center text-lg mb-2">Forgot your PIN?</h3>
            <p className="text-sm text-slate-400 text-center mb-4 leading-relaxed">
              For security, PINs can only be reset by an administrator.
              Contact your supervisor or fleet admin and ask them to use
              <span className="text-slate-200 font-medium"> Reset PIN </span>
              on your profile in the Admin Control Center.
            </p>
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 mb-4 text-xs text-slate-400">
              <div className="font-medium text-slate-300 mb-1">What the admin will do</div>
              <ol className="list-decimal list-inside space-y-1">
                <li>Open Admin → Drivers</li>
                <li>Find your name and tap <strong className="text-amber-400">Reset PIN</strong></li>
                <li>Share the new temporary PIN with you</li>
              </ol>
            </div>
            <button
              onClick={() => setShowForgotPin(false)}
              className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {mode === 'admin' && (
        <div className="w-full max-w-sm card p-6 fade-in">
          {!forceAdmin && (
            <button onClick={() => { setMode(null); setError(''); setAdminPass(''); }} className="text-xs text-slate-400 mb-4 flex items-center gap-1">
              <Icon name="ArrowLeft" size={14} /> Back
            </button>
          )}
          <h2 className="font-semibold mb-4">Admin Passcode</h2>
          <input
            type="password"
            value={adminPass}
            onChange={e => setAdminPass(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && tryAdmin()}
            placeholder="Enter passcode"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4 text-center tracking-widest"
          />
          {error && <div className="text-red-400 text-xs mb-3">{error}</div>}
          <button
            onClick={tryAdmin}
            className="w-full py-3 rounded-xl bg-violet-500 hover:bg-violet-400 text-white font-semibold"
          >
            Unlock Admin
          </button>
          <p className="text-[10px] text-slate-600 text-center mt-3">Default: admin123</p>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Root App
// ─────────────────────────────────────────────
function App() {
  const forceDriver = typeof window !== 'undefined' && window.FLEETSHIFT_MODE === 'driver';
  const forceAdmin = typeof window !== 'undefined' && window.FLEETSHIFT_MODE === 'admin';
  const [state, setState] = useState(loadState);
  const [role, setRole] = useState(null); // null | 'driver' | 'admin'
  const [currentDriver, setCurrentDriver] = useState(null);
  const [online, setOnline] = useState(true);
  const [queue, setQueue] = useState(loadQueue);

  // Persist state
  useEffect(() => {
    saveState(state);
  }, [state]);

  const logout = () => {
    setRole(null);
    setCurrentDriver(null);
  };

  if (!role) {
    return (
      <LoginScreen
        state={state}
        forceDriver={forceDriver}
        forceAdmin={forceAdmin}
        onDriverLogin={(d) => { setCurrentDriver(d); setRole('driver'); }}
        onAdminLogin={() => setRole('admin')}
      />
    );
  }

  if (role === 'driver' && currentDriver) {
    // Always use latest driver data from state
    const liveDriver = state.drivers.find(d => d.id === currentDriver.id) || currentDriver;
    return (
      <DriverPortal
        state={state}
        setState={setState}
        driver={liveDriver}
        online={online}
        setOnline={setOnline}
        queue={queue}
        setQueue={setQueue}
        onLogout={logout}
      />
    );
  }

  if (role === 'admin') {
    return (
      <AdminPortal
        state={state}
        setState={setState}
        online={online}
        setOnline={setOnline}
        queue={queue}
        setQueue={setQueue}
        onLogout={logout}
      />
    );
  }

  return null;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
