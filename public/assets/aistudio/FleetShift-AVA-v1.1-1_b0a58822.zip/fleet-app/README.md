# FleetShift — AVA Transport

Offline-first driver shift logger + admin control center.

**Version:** 1.1 (PIN login + PIN reset)

## Location
```
/home/workdir/artifacts/fleet-app/
├── index.html            ← Combined launcher (Driver + Admin choice)
├── driver-app.html       ← Driver Portal only
├── admin-dashboard.html  ← Admin Control Center only
├── styles.css
├── app.js
└── README.md
```

## How to run
1. Prefer a local server (avoids `file://` fetch limits):
   ```bash
   cd fleet-app && npx serve .
   ```
   Then open the printed URL.
2. Or open `index.html` / `driver-app.html` directly in **Chrome, Edge, or Safari**.
3. Allow **camera** and **location** when the browser asks — required for watermarked photos and GPS stamps.
4. Works offline after the first load (assets cached by the browser).

---

## Features

### Driver Portal
- **PIN login** — select profile + enter 4–6 digit PIN
- **Forgot PIN?** — in-app guidance to request admin reset
- Select assigned vehicle / profile
- **4-stage progressive shift workflow** (mandatory sequential stages):
  1. Before Trip Start — odometer + watermarked photo + GPS
  2. Reached Destination / Parking
  3. Before Return Trip Start
  4. Final Return Parking Completion
- Extra / inter-city trip logging
- Fuel & miscellaneous expenses (Calculation mode: Liters × Price, or Direct Entry)
- History limited to a rolling **30-day** window (privacy isolation)
- Offline queue + auto-sync simulation (status badge)

### Admin Control Center
- Passcode: `admin123`
- Add / activate / deactivate drivers (with PIN assignment)
- Edit driver PINs from the roster
- **Reset PIN** — generates a new temporary 4-digit PIN and displays it for sharing with the driver
- Reassign bus numbers live
- Live uploads feed (trips, extras, expenses)
- Overview stats dashboard
- Master audit trail table

### PIN recovery
- Driver login has a **Forgot PIN?** link that explains how to get a reset from admin.
- Only admins can reset PINs (no self-service reset for security).

### Pre-seeded drivers
| Name              | ID       | Bus      | PIN  | Status  |
|-------------------|----------|----------|------|---------|
| Ahmed Al-Mansoori | DRV-1001 | DXB-4821 | 1001 | Active  |
| Mohammed Hassan   | DRV-1002 | SHJ-3190 | 1002 | Active  |
| Fatima Al-Kaabi   | DRV-1003 | AUH-7742 | 1003 | Active  |
| Rajesh Kumar      | DRV-1004 | DXB-5518 | 1004 | Locked  |

---

## Technical notes
- **Stack**: React 18 (CDN) + Tailwind CSS + Lucide icons
- **Storage**: `localStorage` (trips, drivers, expenses, offline queue)
- **Camera**: `getUserMedia` + canvas watermark (timestamp, driver, bus, GPS)
- **Network simulator**: toggle Online Sync ↔ Offline Mode; queued items flush when online
- Cloud sync to Google Sheets / Drive is **simulated** (console + status badge). Production would wire to Apps Script like the original AVA system.

## Limitations (prototype)
- Data lives in `localStorage` (clears if you clear site data).
- “Cloud sync” is simulated.
- Best on phone or with DevTools mobile emulation.
- Camera / GPS require HTTPS or localhost (`file://` may restrict permissions in some browsers).

---

Built as an evolution of the AVA Transport trip log system.
